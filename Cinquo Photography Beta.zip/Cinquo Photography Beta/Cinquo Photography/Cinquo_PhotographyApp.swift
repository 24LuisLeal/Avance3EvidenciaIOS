//
//  Cinquo_PhotographyApp.swift
//  Cinquo Photography
//
//  Created by Luis Leal on 25/11/21.
//

import SwiftUI

@main
struct Cinquo_PhotographyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
